# BPH Publisher HD

APK Android para analizar la calidad real de un video y compartirlo en TikTok, Instagram y Facebook usando las apps oficiales.

## Que hace

- Elige video desde galeria, archivos o Google Drive.
- Lee datos tecnicos:
  - resolucion real del archivo
  - resolucion visual
  - rotacion
  - formato/MIME
  - codec de video
  - codec de audio
  - FPS
  - bitrate
  - peso
  - duracion
- Indica si el archivo esta:
  - APTO FULL HD
  - APTO HD CON ALERTA
  - APTO HD BASICO
  - RIESGO DE BAJA CALIDAD
- Comparte el archivo original sin recomprimir y sin bajar resolucion.
- Copia la descripcion al portapapeles antes de abrir la red social.
- Tiene boton para abrir TikTok, Instagram y Facebook uno por uno.

## Importante

Esta primera version es publicacion asistida, no autopublicacion total.

La app abre TikTok, Instagram o Facebook con el video. Tu revisas y presionas Publicar dentro de cada red social.

Esto se hizo asi para evitar plataformas intermedias que puedan bajar la calidad o pedir pago. La publicacion automatica total requiere APIs oficiales, permisos, tokens y aprobacion de TikTok/Meta.

## Regla de calidad

La app no comprime mas. Comprimir mas no mejora HD. La app protege el archivo original:

- Si el video ya es 1080 x 1920, lo comparte asi.
- Si es 720 x 1280, lo comparte asi.
- Si es 540 x 960, avisa riesgo de baja calidad.
- Si esta girado o tiene rotacion rara, avisa.

## Como compilar en GitHub

1. Descomprime este ZIP.
2. Sube la carpeta completa a un repositorio de GitHub.
3. Entra a la pestana **Actions**.
4. Ejecuta **Build APK**.
5. Cuando termine, entra al job y descarga el artifact:
   **BPH-Publisher-HD-debug-apk**.
6. Dentro estara el APK debug.

## Como abrir en Android Studio

1. Android Studio > Open.
2. Selecciona la carpeta `BPH_Publisher_HD`.
3. Espera sincronizacion Gradle.
4. Build > Build APK(s).

## Paquete

`com.bph.publisherhd`

## Version

1.0 debug
