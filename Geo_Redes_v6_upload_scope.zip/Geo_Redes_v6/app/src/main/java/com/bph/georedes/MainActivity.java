package com.bph.georedes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_PICK_VIDEO = 1001;
    private static final String PREF = "geo_redes_pref";

    private final int BG = Color.rgb(5, 7, 13);
    private final int CARD = Color.rgb(17, 24, 39);
    private final int CARD2 = Color.rgb(24, 34, 54);
    private final int TXT = Color.rgb(245, 247, 250);
    private final int MUTED = Color.rgb(170, 180, 196);
    private final int BLUE = Color.rgb(0, 229, 255);
    private final int GREEN = Color.rgb(0, 200, 83);
    private final int RED = Color.rgb(255, 82, 82);
    private final int YELLOW = Color.rgb(255, 214, 0);

    private SharedPreferences prefs;
    private Uri selectedVideoUri;
    private VideoInfo videoInfo;

    private TextView tvFile;
    private TextView tvStatus;
    private TextView tvStats;
    private TextView tvApiStatus;
    private TextView tvConsole;
    private EditText edtCaption;
    private CheckBox chkTikTok;
    private CheckBox chkInstagram;
    private CheckBox chkFacebook;
    private ProgressBar progress;

    private EditText edtTikTokKey;
    private EditText edtTikTokSecret;
    private EditText edtTikTokRedirect;
    private EditText edtMetaAppId;
    private EditText edtMetaSecret;
    private EditText edtMetaRedirect;
    private EditText edtInstagramPublicUrl;
    private TextView tvSettingsStatus;
    private TextView tvDiagnostic;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        handleOAuthIntent(getIntent());
        showMain();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleOAuthIntent(intent);
    }

    private void showMain() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(54)));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("ic_launcher", "drawable", getPackageName()));
        header.addView(logo, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(10), 0, 0, 0);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -1, 1));
        titleBox.addView(label("Geo Redes", 22, TXT, true));
        TextView sub = label("Publica sin bajar resolución", 12, MUTED, false);
        titleBox.addView(sub);

        Button apiBtn = smallButton("APIs");
        header.addView(apiBtn, new LinearLayout.LayoutParams(dp(70), dp(42)));
        apiBtn.setOnClickListener(v -> showApiSettings());

        Button diagBtn = smallButton("Diag");
        LinearLayout.LayoutParams diagLp = new LinearLayout.LayoutParams(dp(70), dp(42));
        diagLp.leftMargin = dp(6);
        header.addView(diagBtn, diagLp);
        diagBtn.setOnClickListener(v -> showDiagnostic());

        LinearLayout cardVideo = card();
        page.addView(cardVideo, new LinearLayout.LayoutParams(-1, dp(172)));

        LinearLayout rowVideo = new LinearLayout(this);
        rowVideo.setOrientation(LinearLayout.HORIZONTAL);
        rowVideo.setGravity(Gravity.CENTER_VERTICAL);
        cardVideo.addView(rowVideo, new LinearLayout.LayoutParams(-1, dp(54)));

        Button pick = primaryButton("Elegir video");
        rowVideo.addView(pick, new LinearLayout.LayoutParams(dp(140), dp(46)));
        pick.setOnClickListener(v -> pickVideo());

        tvFile = label("Sin video seleccionado", 13, MUTED, false);
        tvFile.setGravity(Gravity.CENTER_VERTICAL);
        tvFile.setPadding(dp(10), 0, 0, 0);
        rowVideo.addView(tvFile, new LinearLayout.LayoutParams(0, dp(46), 1));

        tvStatus = pill("PENDIENTE", MUTED);
        cardVideo.addView(tvStatus, new LinearLayout.LayoutParams(-1, dp(38)));

        tvStats = label("Resolución: -   FPS: -   Peso: -   Bitrate: -", 13, TXT, false);
        tvStats.setPadding(0, dp(8), 0, 0);
        cardVideo.addView(tvStats, new LinearLayout.LayoutParams(-1, dp(64)));

        LinearLayout captionBox = card();
        captionBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        page.addView(captionBox, new LinearLayout.LayoutParams(-1, dp(112)));
        captionBox.addView(label("Descripción / hashtags", 14, MUTED, true));
        edtCaption = new EditText(this);
        edtCaption.setTextColor(TXT);
        edtCaption.setHintTextColor(Color.rgb(110, 120, 135));
        edtCaption.setHint("Escribe el texto para tus redes...");
        edtCaption.setTextSize(15);
        edtCaption.setMinLines(2);
        edtCaption.setMaxLines(3);
        edtCaption.setGravity(Gravity.TOP);
        edtCaption.setBackgroundColor(Color.TRANSPARENT);
        captionBox.addView(edtCaption, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout networkCard = card();
        page.addView(networkCard, new LinearLayout.LayoutParams(-1, dp(120)));
        networkCard.addView(label("Redes", 15, TXT, true));
        LinearLayout checks = new LinearLayout(this);
        checks.setOrientation(LinearLayout.HORIZONTAL);
        networkCard.addView(checks, new LinearLayout.LayoutParams(-1, dp(44)));
        chkTikTok = check("TikTok API");
        chkInstagram = check("Instagram API");
        chkFacebook = check("Facebook API");
        chkTikTok.setChecked(true);
        chkFacebook.setChecked(true);
        checks.addView(chkTikTok, new LinearLayout.LayoutParams(0, -1, 1));
        checks.addView(chkInstagram, new LinearLayout.LayoutParams(0, -1, 1));
        checks.addView(chkFacebook, new LinearLayout.LayoutParams(0, -1, 1));
        tvApiStatus = label(apiSummary(), 12, MUTED, false);
        networkCard.addView(tvApiStatus, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        page.addView(buttons, new LinearLayout.LayoutParams(-1, dp(54)));
        Button publishApi = primaryButton("Publicar API");
        Button share = darkButton("Manual");
        buttons.addView(publishApi, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(10), dp(1));
        View spacer = new View(this);
        buttons.addView(spacer, sp);
        buttons.addView(share, new LinearLayout.LayoutParams(dp(110), dp(50)));
        publishApi.setOnClickListener(v -> publishSelectedNetworks());
        share.setOnClickListener(v -> shareAllManual());

        LinearLayout consoleCard = card();
        page.addView(consoleCard, new LinearLayout.LayoutParams(-1, 0, 1));
        consoleCard.addView(label("Estado", 14, MUTED, true));
        tvConsole = label("Listo. Configura APIs para publicar automático.", 12, TXT, false);
        tvConsole.setPadding(0, dp(6), 0, 0);
        consoleCard.addView(tvConsole, new LinearLayout.LayoutParams(-1, 0, 1));
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        consoleCard.addView(progress, new LinearLayout.LayoutParams(-1, dp(34)));

        setContentView(root);
    }

    private void showApiSettings() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(12), dp(14), dp(12));
        scroll.addView(page);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(54)));
        Button back = darkButton("Volver");
        header.addView(back, new LinearLayout.LayoutParams(dp(95), dp(44)));
        back.setOnClickListener(v -> showMain());
        TextView title = label("Configurar APIs", 22, TXT, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(12), 0, 0, 0);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        LinearLayout tiktok = card();
        page.addView(tiktok, new LinearLayout.LayoutParams(-1, -2));
        tiktok.addView(label("TikTok API", 18, TXT, true));
        tiktok.addView(label("Necesitas Login Kit + Content Posting API con scope video.upload. Redirect HTTPS: /Redes/oauth/tiktok/", 12, MUTED, false));
        edtTikTokKey = input("TikTok Client Key", prefs.getString("tiktok_key", ""), false);
        edtTikTokSecret = input("TikTok Client Secret", prefs.getString("tiktok_secret", ""), true);
        edtTikTokRedirect = input("Redirect URI", prefs.getString("tiktok_redirect", "https://brian7pacco7-dotcom.github.io/Redes/oauth/tiktok/"), false);
        tiktok.addView(edtTikTokKey);
        tiktok.addView(edtTikTokSecret);
        tiktok.addView(edtTikTokRedirect);
        LinearLayout ttBtns = new LinearLayout(this);
        ttBtns.setOrientation(LinearLayout.HORIZONTAL);
        tiktok.addView(ttBtns, new LinearLayout.LayoutParams(-1, dp(52)));
        Button saveTt = darkButton("Guardar");
        Button loginTt = primaryButton("Conectar TikTok");
        ttBtns.addView(saveTt, new LinearLayout.LayoutParams(0, dp(48), 1));
        ttBtns.addView(loginTt, new LinearLayout.LayoutParams(0, dp(48), 1));
        saveTt.setOnClickListener(v -> saveTikTokConfig());
        loginTt.setOnClickListener(v -> { saveTikTokConfig(); openTikTokOAuth(); });

        LinearLayout meta = card();
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2);
        mlp.topMargin = dp(10);
        page.addView(meta, mlp);
        meta.addView(label("Meta API: Instagram + Facebook", 18, TXT, true));
        meta.addView(label("Facebook Page puede subir archivo. Instagram API necesita URL pública HTTPS del video.", 12, MUTED, false));
        edtMetaAppId = input("Meta App ID", prefs.getString("meta_app_id", ""), false);
        edtMetaSecret = input("Meta App Secret", prefs.getString("meta_secret", ""), true);
        edtMetaRedirect = input("Redirect URI", prefs.getString("meta_redirect", "georedes://oauth/meta"), false);
        edtInstagramPublicUrl = input("URL pública para Instagram Reels (opcional)", prefs.getString("ig_public_url", ""), false);
        meta.addView(edtMetaAppId);
        meta.addView(edtMetaSecret);
        meta.addView(edtMetaRedirect);
        meta.addView(edtInstagramPublicUrl);
        LinearLayout metaBtns = new LinearLayout(this);
        metaBtns.setOrientation(LinearLayout.HORIZONTAL);
        meta.addView(metaBtns, new LinearLayout.LayoutParams(-1, dp(52)));
        Button saveMeta = darkButton("Guardar");
        Button loginMeta = primaryButton("Conectar Meta");
        metaBtns.addView(saveMeta, new LinearLayout.LayoutParams(0, dp(48), 1));
        metaBtns.addView(loginMeta, new LinearLayout.LayoutParams(0, dp(48), 1));
        saveMeta.setOnClickListener(v -> saveMetaConfig());
        loginMeta.setOnClickListener(v -> { saveMetaConfig(); openMetaOAuth(); });

        LinearLayout info = card();
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(10);
        page.addView(info, ilp);
        tvSettingsStatus = label(apiSummaryDetailed(), 13, TXT, false);
        info.addView(tvSettingsStatus);

        Button diag = primaryButton("Abrir diagnóstico API");
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, dp(48));
        dlp.topMargin = dp(10);
        page.addView(diag, dlp);
        diag.setOnClickListener(v -> showDiagnostic());

        setContentView(scroll);
    }

    private void showDiagnostic() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(12), dp(14), dp(12));
        scroll.addView(page);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(54)));
        Button back = darkButton("Volver");
        header.addView(back, new LinearLayout.LayoutParams(dp(95), dp(44)));
        back.setOnClickListener(v -> showMain());
        TextView title = label("Diagnóstico API", 22, TXT, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(12), 0, 0, 0);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        LinearLayout info = card();
        page.addView(info, new LinearLayout.LayoutParams(-1, -2));
        info.addView(label("Usa esto para saber exactamente dónde falla: login, permisos, token o subida.", 13, MUTED, false));
        info.addView(label(apiSummaryDetailed(), 13, TXT, false));

        LinearLayout tt = card();
        page.addView(tt, new LinearLayout.LayoutParams(-1, -2));
        tt.addView(label("TikTok", 18, TXT, true));
        tt.addView(label("Primero conecta. Luego prueba usuario, permisos y subida con un video corto.", 12, MUTED, false));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        tt.addView(grid, new LinearLayout.LayoutParams(-1, -2));
        Button b1 = darkButton("Login TikTok");
        Button b2 = darkButton("Ver usuario");
        Button b3 = darkButton("Ver permisos");
        Button b4 = primaryButton("Subida prueba");
        addGridButton(grid, b1); addGridButton(grid, b2); addGridButton(grid, b3); addGridButton(grid, b4);
        b1.setOnClickListener(v -> openTikTokOAuth());
        b2.setOnClickListener(v -> diagnosticTikTokUser());
        b3.setOnClickListener(v -> diagnosticTikTokCreator());
        b4.setOnClickListener(v -> confirmTikTokTestUpload());

        LinearLayout meta = card();
        page.addView(meta, new LinearLayout.LayoutParams(-1, -2));
        meta.addView(label("Meta: Facebook + Instagram", 18, TXT, true));
        meta.addView(label("Meta sirve para revisar login y páginas. Instagram Reels por API exige URL pública HTTPS del video.", 12, MUTED, false));
        GridLayout gridMeta = new GridLayout(this);
        gridMeta.setColumnCount(2);
        meta.addView(gridMeta, new LinearLayout.LayoutParams(-1, -2));
        Button m1 = darkButton("Login Meta");
        Button m2 = darkButton("Ver páginas");
        Button m3 = primaryButton("Probar Facebook");
        Button m4 = darkButton("Copiar reporte");
        addGridButton(gridMeta, m1); addGridButton(gridMeta, m2); addGridButton(gridMeta, m3); addGridButton(gridMeta, m4);
        m1.setOnClickListener(v -> openMetaOAuth());
        m2.setOnClickListener(v -> diagnosticMetaPages());
        m3.setOnClickListener(v -> confirmFacebookTestUpload());
        m4.setOnClickListener(v -> copyDiagnosticReport());

        LinearLayout console = card();
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(250));
        page.addView(console, clp);
        console.addView(label("Reporte técnico", 14, MUTED, true));
        tvDiagnostic = label("Sin pruebas todavía. Cuando salga error, copia este reporte y mándame captura o texto.", 12, TXT, false);
        tvDiagnostic.setPadding(0, dp(8), 0, 0);
        console.addView(tvDiagnostic, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(scroll);
    }

    private void addGridButton(GridLayout grid, Button button) {
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = dp(48);
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(dp(4), dp(6), dp(4), dp(2));
        button.setLayoutParams(lp);
        grid.addView(button);
    }

    private void pickVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_PICK_VIDEO && result == RESULT_OK && data != null && data.getData() != null) {
            selectedVideoUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selectedVideoUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            videoInfo = analyzeVideo(selectedVideoUri);
            updateVideoUi();
        }
    }

    private void updateVideoUi() {
        if (videoInfo == null) return;
        tvFile.setText(shorten(videoInfo.name, 30));
        int color = videoInfo.status.startsWith("APTO FULL HD") ? GREEN : (videoInfo.status.startsWith("APTO HD") ? YELLOW : RED);
        tvStatus.setText(videoInfo.status + "  |  salida: " + videoInfo.visualWidth + " x " + videoInfo.visualHeight);
        tvStatus.setTextColor(color);
        tvStats.setText("Resolución: " + videoInfo.visualWidth + "x" + videoInfo.visualHeight
                + "   FPS: " + fmt(videoInfo.fps)
                + "\nPeso: " + formatMb(videoInfo.sizeBytes)
                + "   Bitrate: " + formatMbps(videoInfo.bitrate)
                + "   Duración: " + formatDuration(videoInfo.durationMs));
    }

    private VideoInfo analyzeVideo(Uri uri) {
        VideoInfo info = new VideoInfo();
        info.name = queryName(uri);
        info.sizeBytes = querySize(uri);
        info.mime = getContentResolver().getType(uri);
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(this, uri);
            info.width = parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            info.height = parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            info.rotation = parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
            info.bitrate = parseLong(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE));
            info.durationMs = parseLong(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            info.videoCodec = safe(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE));
            info.fps = parseDouble(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE));
        } catch (Exception e) {
            info.error = e.getMessage();
        } finally {
            try { mmr.release(); } catch (Exception ignored) { }
        }
        if (info.rotation == 90 || info.rotation == 270) {
            info.visualWidth = info.height;
            info.visualHeight = info.width;
        } else {
            info.visualWidth = info.width;
            info.visualHeight = info.height;
        }
        evaluate(info);
        return info;
    }

    private void evaluate(VideoInfo info) {
        boolean vertical = info.visualHeight > info.visualWidth;
        boolean fullHdVertical = info.visualWidth >= 1080 && info.visualHeight >= 1920 && vertical;
        boolean hdVertical = info.visualWidth >= 720 && info.visualHeight >= 1280 && vertical;
        boolean mp4 = safe(info.mime).contains("mp4") || info.name.toLowerCase(Locale.ROOT).endsWith(".mp4");
        boolean bitrateOk = info.bitrate <= 0 || info.bitrate >= 5_000_000;
        if (fullHdVertical && mp4 && bitrateOk) {
            info.status = "APTO FULL HD";
        } else if (hdVertical && mp4) {
            info.status = "APTO HD CON ALERTA";
        } else if (vertical) {
            info.status = "RIESGO DE BAJA CALIDAD";
        } else {
            info.status = "NO RECOMENDADO: NO ES VERTICAL";
        }
    }

    private void publishSelectedNetworks() {
        if (selectedVideoUri == null || videoInfo == null) {
            toast("Primero elige un video.");
            return;
        }
        copyCaption();
        setBusy(true);
        log("Iniciando publicación. Archivo: " + videoInfo.visualWidth + "x" + videoInfo.visualHeight + ", sin recomprimir.");
        new Thread(() -> {
            if (chkTikTok.isChecked()) publishTikTokApi();
            if (chkFacebook.isChecked()) publishFacebookApi();
            if (chkInstagram.isChecked()) publishInstagramApiOrFallback();
            runOnUiThread(() -> setBusy(false));
        }).start();
    }

    private void publishTikTokApi() {
        try {
            String token = prefs.getString("tiktok_token", "");
            if (token.isEmpty()) {
                log("TikTok: falta conectar cuenta en APIs.");
                return;
            }
            log("TikTok: consultando cuenta...");
            JSONObject creator = postJson("https://open.tiktokapis.com/v2/post/publish/creator_info/query/", token, new JSONObject());
            JSONArray privacyOptions = creator.optJSONObject("data") != null
                    ? creator.optJSONObject("data").optJSONArray("privacy_level_options") : null;
            String privacy = pickPrivacy(privacyOptions);
            log("TikTok: privacidad usada: " + privacy);

            long size = videoInfo.sizeBytes;
            if (size <= 0) size = countBytes(selectedVideoUri);
            JSONObject body = new JSONObject();
            JSONObject postInfo = new JSONObject();
            postInfo.put("title", getCaption());
            postInfo.put("privacy_level", privacy);
            postInfo.put("disable_duet", false);
            postInfo.put("disable_comment", false);
            postInfo.put("disable_stitch", false);
            postInfo.put("video_cover_timestamp_ms", 1000);
            postInfo.put("brand_content_toggle", false);
            postInfo.put("brand_organic_toggle", false);
            postInfo.put("is_aigc", false);
            long chunkSize = Math.min(size, 32L * 1024L * 1024L);
            int totalChunks = (int) ((size + chunkSize - 1) / chunkSize);
            JSONObject sourceInfo = new JSONObject();
            sourceInfo.put("source", "FILE_UPLOAD");
            sourceInfo.put("video_size", size);
            sourceInfo.put("chunk_size", chunkSize);
            sourceInfo.put("total_chunk_count", totalChunks);
            body.put("post_info", postInfo);
            body.put("source_info", sourceInfo);

            log("TikTok: inicializando subida...");
            JSONObject init = postJson("https://open.tiktokapis.com/v2/post/publish/video/init/", token, body);
            JSONObject data = init.optJSONObject("data");
            if (data == null || data.optString("upload_url").isEmpty()) {
                log("TikTok: no llegó upload_url. Respuesta: " + init.toString());
                return;
            }
            String uploadUrl = data.optString("upload_url");
            String publishId = data.optString("publish_id");
            log("TikTok: subiendo archivo original en " + totalChunks + " parte(s)...");
            putVideo(uploadUrl, selectedVideoUri, size, chunkSize);
            log("TikTok: subida enviada. publish_id: " + publishId);
            JSONObject statusBody = new JSONObject();
            statusBody.put("publish_id", publishId);
            JSONObject status = postJson("https://open.tiktokapis.com/v2/post/publish/status/fetch/", token, statusBody);
            log("TikTok estado: " + status.toString());
        } catch (Exception e) {
            log("TikTok error: " + e.getMessage());
        }
    }

    private void publishFacebookApi() {
        try {
            String pageId = prefs.getString("fb_page_id", "");
            String pageToken = prefs.getString("fb_page_token", "");
            if (pageId.isEmpty() || pageToken.isEmpty()) {
                log("Facebook: falta conectar Meta o no hay página disponible.");
                return;
            }
            log("Facebook: subiendo video a página " + pageId + "...");
            String endpoint = "https://graph-video.facebook.com/v20.0/" + enc(pageId) + "/videos";
            JSONObject res = multipartVideoPost(endpoint, pageToken, selectedVideoUri, "source", "description", getCaption());
            log("Facebook respuesta: " + res.toString());
        } catch (Exception e) {
            log("Facebook error: " + e.getMessage());
        }
    }

    private void publishInstagramApiOrFallback() {
        try {
            String igId = prefs.getString("ig_user_id", "");
            String pageToken = prefs.getString("fb_page_token", "");
            String videoUrl = prefs.getString("ig_public_url", "");
            if (igId.isEmpty() || pageToken.isEmpty()) {
                log("Instagram: falta conectar Meta o no se detectó cuenta profesional vinculada.");
                openShareOnUi("com.instagram.android");
                return;
            }
            if (videoUrl.trim().isEmpty()) {
                log("Instagram API: necesita URL pública HTTPS del video. Se abrirá Instagram manual como respaldo.");
                openShareOnUi("com.instagram.android");
                return;
            }
            log("Instagram: creando contenedor REELS...");
            String createUrl = "https://graph.facebook.com/v20.0/" + enc(igId) + "/media";
            String body = "media_type=REELS&video_url=" + enc(videoUrl) + "&caption=" + enc(getCaption()) + "&access_token=" + enc(pageToken);
            JSONObject create = postForm(createUrl, body);
            String creationId = create.optString("id");
            if (creationId.isEmpty()) {
                log("Instagram: no se creó contenedor. " + create.toString());
                return;
            }
            log("Instagram: contenedor creado. Esperando procesamiento...");
            Thread.sleep(12000);
            String publishUrl = "https://graph.facebook.com/v20.0/" + enc(igId) + "/media_publish";
            JSONObject pub = postForm(publishUrl, "creation_id=" + enc(creationId) + "&access_token=" + enc(pageToken));
            log("Instagram respuesta: " + pub.toString());
        } catch (Exception e) {
            log("Instagram error: " + e.getMessage());
        }
    }

    private void diagnosticTikTokUser() {
        String token = prefs.getString("tiktok_token", "");
        if (token.isEmpty()) { log("TikTok usuario: falta token. Primero toca Login TikTok."); return; }
        new Thread(() -> {
            try {
                log("TikTok usuario: probando token...");
                JSONObject res = getJson("https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url", token);
                log("TikTok usuario OK: " + res.toString());
            } catch (Exception e) {
                log("TikTok usuario ERROR: " + e.getMessage());
            }
        }).start();
    }

    private void diagnosticTikTokCreator() {
        String token = prefs.getString("tiktok_token", "");
        if (token.isEmpty()) { log("TikTok permisos: falta token. Primero toca Login TikTok."); return; }
        new Thread(() -> {
            try {
                log("TikTok permisos: consultando creator_info...");
                JSONObject res = postJson("https://open.tiktokapis.com/v2/post/publish/creator_info/query/", token, new JSONObject());
                log("TikTok permisos OK: " + res.toString());
            } catch (Exception e) {
                log("TikTok permisos ERROR: " + e.getMessage());
            }
        }).start();
    }

    private void confirmTikTokTestUpload() {
        if (selectedVideoUri == null || videoInfo == null) { toast("Primero elige un video corto de prueba."); return; }
        new AlertDialog.Builder(this)
                .setTitle("Subida de prueba TikTok")
                .setMessage("Esto intentará subir el video por API. Puede quedar privado si TikTok aún no aprobó la app. Usa un video corto de prueba.")
                .setPositiveButton("Probar", (d, w) -> new Thread(() -> publishTikTokApi()).start())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void diagnosticMetaPages() {
        String token = prefs.getString("meta_token", "");
        if (token.isEmpty()) { log("Meta páginas: falta token. Primero toca Login Meta."); return; }
        new Thread(() -> {
            log("Meta páginas: consultando páginas vinculadas...");
            loadMetaPages(token);
        }).start();
    }

    private void confirmFacebookTestUpload() {
        if (selectedVideoUri == null || videoInfo == null) { toast("Primero elige un video corto de prueba."); return; }
        new AlertDialog.Builder(this)
                .setTitle("Subida de prueba Facebook")
                .setMessage("Esto intentará subir el video a la página de Facebook detectada por Meta.")
                .setPositiveButton("Probar", (d, w) -> new Thread(() -> publishFacebookApi()).start())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void copyDiagnosticReport() {
        String text = tvDiagnostic == null ? apiSummaryDetailed() : tvDiagnostic.getText().toString();
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Geo Redes diagnóstico", text));
        toast("Reporte copiado.");
    }

    private void shareAllManual() {
        if (selectedVideoUri == null) {
            toast("Primero elige un video.");
            return;
        }
        copyCaption();
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("video/*");
        share.putExtra(Intent.EXTRA_STREAM, selectedVideoUri);
        share.putExtra(Intent.EXTRA_TEXT, getCaption());
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, "Compartir video"));
    }

    private void openShareOnUi(String pkg) {
        runOnUiThread(() -> {
            try {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("video/*");
                share.putExtra(Intent.EXTRA_STREAM, selectedVideoUri);
                share.putExtra(Intent.EXTRA_TEXT, getCaption());
                share.setPackage(pkg);
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(share);
            } catch (Exception e) {
                log("No se pudo abrir app: " + pkg);
            }
        });
    }

    private void openTikTokOAuth() {
        String key = prefs.getString("tiktok_key", "");
        String redirect = prefs.getString("tiktok_redirect", "https://brian7pacco7-dotcom.github.io/Redes/oauth/tiktok/");
        if (key.isEmpty()) {
            toast("Falta TikTok Client Key.");
            return;
        }
        String state = UUID.randomUUID().toString();
        prefs.edit().putString("tiktok_state", state).apply();
        String scope = "user.info.basic,video.upload";
        String url = "https://www.tiktok.com/v2/auth/authorize/"
                + "?client_key=" + enc(key)
                + "&response_type=code"
                + "&scope=" + enc(scope)
                + "&redirect_uri=" + enc(redirect)
                + "&state=" + enc(state);
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private void openMetaOAuth() {
        String appId = prefs.getString("meta_app_id", "");
        String redirect = prefs.getString("meta_redirect", "georedes://oauth/meta");
        if (appId.isEmpty()) {
            toast("Falta Meta App ID.");
            return;
        }
        String state = UUID.randomUUID().toString();
        prefs.edit().putString("meta_state", state).apply();
        String scope = "pages_show_list,pages_read_engagement,pages_manage_posts,instagram_basic,instagram_content_publish";
        String url = "https://www.facebook.com/v20.0/dialog/oauth"
                + "?client_id=" + enc(appId)
                + "&redirect_uri=" + enc(redirect)
                + "&scope=" + enc(scope)
                + "&response_type=code"
                + "&state=" + enc(state);
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private void handleOAuthIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        if (!"georedes".equals(uri.getScheme())) return;
        String path = uri.getPath() == null ? "" : uri.getPath();
        String code = uri.getQueryParameter("code");
        String error = uri.getQueryParameter("error");
        if (error != null) {
            toast("OAuth error: " + error);
            return;
        }
        if (code == null || code.isEmpty()) return;
        if (path.contains("tiktok")) {
            toast("TikTok devolvió código. Obteniendo token...");
            new Thread(() -> exchangeTikTokCode(code)).start();
        } else if (path.contains("meta")) {
            toast("Meta devolvió código. Obteniendo token...");
            new Thread(() -> exchangeMetaCode(code)).start();
        }
    }

    private void exchangeTikTokCode(String code) {
        try {
            String body = "client_key=" + enc(prefs.getString("tiktok_key", ""))
                    + "&client_secret=" + enc(prefs.getString("tiktok_secret", ""))
                    + "&code=" + enc(code)
                    + "&grant_type=authorization_code"
                    + "&redirect_uri=" + enc(prefs.getString("tiktok_redirect", "https://brian7pacco7-dotcom.github.io/Redes/oauth/tiktok/"));
            JSONObject res = postForm("https://open.tiktokapis.com/v2/oauth/token/", body);
            String token = res.optString("access_token");
            if (token.isEmpty()) token = res.optJSONObject("data") != null ? res.optJSONObject("data").optString("access_token") : "";
            if (token.isEmpty()) {
                log("TikTok token error: " + res.toString());
                return;
            }
            prefs.edit()
                    .putString("tiktok_token", token)
                    .putString("tiktok_refresh", res.optString("refresh_token"))
                    .putString("tiktok_open_id", res.optString("open_id"))
                    .apply();
            log("TikTok conectado correctamente.");
        } catch (Exception e) {
            log("TikTok OAuth error: " + e.getMessage());
        }
    }

    private void exchangeMetaCode(String code) {
        try {
            String url = "https://graph.facebook.com/v20.0/oauth/access_token"
                    + "?client_id=" + enc(prefs.getString("meta_app_id", ""))
                    + "&redirect_uri=" + enc(prefs.getString("meta_redirect", "georedes://oauth/meta"))
                    + "&client_secret=" + enc(prefs.getString("meta_secret", ""))
                    + "&code=" + enc(code);
            JSONObject res = getJson(url, null);
            String token = res.optString("access_token");
            if (token.isEmpty()) {
                log("Meta token error: " + res.toString());
                return;
            }
            prefs.edit().putString("meta_token", token).apply();
            log("Meta conectado. Buscando páginas...");
            loadMetaPages(token);
        } catch (Exception e) {
            log("Meta OAuth error: " + e.getMessage());
        }
    }

    private void loadMetaPages(String userToken) {
        try {
            String url = "https://graph.facebook.com/v20.0/me/accounts?fields=id,name,access_token,instagram_business_account{id,username}&access_token=" + enc(userToken);
            JSONObject res = getJson(url, null);
            JSONArray data = res.optJSONArray("data");
            if (data == null || data.length() == 0) {
                log("Meta: no se encontraron páginas. Respuesta: " + res.toString());
                return;
            }
            JSONObject page = data.getJSONObject(0);
            String pageId = page.optString("id");
            String pageToken = page.optString("access_token");
            String pageName = page.optString("name");
            String igId = "";
            JSONObject ig = page.optJSONObject("instagram_business_account");
            if (ig != null) igId = ig.optString("id");
            prefs.edit()
                    .putString("fb_page_id", pageId)
                    .putString("fb_page_token", pageToken)
                    .putString("fb_page_name", pageName)
                    .putString("ig_user_id", igId)
                    .apply();
            log("Meta listo. Página: " + pageName + ". IG ID: " + (igId.isEmpty() ? "no detectado" : igId));
        } catch (Exception e) {
            log("Meta páginas error: " + e.getMessage());
        }
    }

    private void saveTikTokConfig() {
        prefs.edit()
                .putString("tiktok_key", edtTikTokKey.getText().toString().trim())
                .putString("tiktok_secret", edtTikTokSecret.getText().toString().trim())
                .putString("tiktok_redirect", edtTikTokRedirect.getText().toString().trim())
                .apply();
        toast("TikTok guardado.");
    }

    private void saveMetaConfig() {
        prefs.edit()
                .putString("meta_app_id", edtMetaAppId.getText().toString().trim())
                .putString("meta_secret", edtMetaSecret.getText().toString().trim())
                .putString("meta_redirect", edtMetaRedirect.getText().toString().trim())
                .putString("ig_public_url", edtInstagramPublicUrl.getText().toString().trim())
                .apply();
        toast("Meta guardado.");
    }

    private JSONObject postJson(String endpoint, String bearerToken, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(30000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + bearerToken);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        return readJson(c);
    }

    private JSONObject postForm(String endpoint, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(30000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        return readJson(c);
    }

    private JSONObject getJson(String endpoint, String bearerToken) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(30000);
        c.setReadTimeout(60000);
        if (bearerToken != null) c.setRequestProperty("Authorization", "Bearer " + bearerToken);
        return readJson(c);
    }

    private JSONObject readJson(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAllText(is);
        if (text.trim().isEmpty()) text = "{}";
        JSONObject obj = new JSONObject(text);
        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code + ": " + obj.toString());
        }
        return obj;
    }

    private void putVideo(String uploadUrl, Uri uri, long size, long chunkSize) throws Exception {
        try (InputStream is = new BufferedInputStream(getContentResolver().openInputStream(uri))) {
            byte[] buffer = new byte[64 * 1024];
            long start = 0;
            int chunkIndex = 1;
            while (start < size) {
                long end = Math.min(size - 1, start + chunkSize - 1);
                long partLen = end - start + 1;
                HttpURLConnection c = (HttpURLConnection) new URL(uploadUrl).openConnection();
                c.setRequestMethod("PUT");
                c.setConnectTimeout(30000);
                c.setReadTimeout(180000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "video/mp4");
                c.setRequestProperty("Content-Range", "bytes " + start + "-" + end + "/" + size);
                c.setFixedLengthStreamingMode(partLen);
                try (OutputStream os = c.getOutputStream()) {
                    long remaining = partLen;
                    while (remaining > 0) {
                        int want = (int) Math.min(buffer.length, remaining);
                        int n = is.read(buffer, 0, want);
                        if (n < 0) throw new Exception("Lectura incompleta del video.");
                        os.write(buffer, 0, n);
                        remaining -= n;
                    }
                }
                int code = c.getResponseCode();
                if (code < 200 || code >= 300) {
                    throw new Exception("PUT HTTP " + code + ": " + readAllText(c.getErrorStream()));
                }
                log("TikTok: parte " + chunkIndex + " subida (" + formatMb(end + 1) + " / " + formatMb(size) + ").");
                start = end + 1;
                chunkIndex++;
            }
        }
    }

    private JSONObject multipartVideoPost(String endpoint, String accessToken, Uri fileUri, String fileField, String textField, String description) throws Exception {
        String boundary = "GeoRedes" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(30000);
        c.setReadTimeout(180000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (DataOutputStream out = new DataOutputStream(c.getOutputStream())) {
            writeFormField(out, boundary, "access_token", accessToken);
            writeFormField(out, boundary, textField, description);
            out.writeBytes("--" + boundary + "\r\n");
            out.writeBytes("Content-Disposition: form-data; name=\"" + fileField + "\"; filename=\"video.mp4\"\r\n");
            out.writeBytes("Content-Type: video/mp4\r\n\r\n");
            try (InputStream is = getContentResolver().openInputStream(fileUri)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = is.read(buf)) >= 0) out.write(buf, 0, n);
            }
            out.writeBytes("\r\n--" + boundary + "--\r\n");
        }
        return readJson(c);
    }

    private void writeFormField(DataOutputStream out, String boundary, String name, String value) throws Exception {
        out.writeBytes("--" + boundary + "\r\n");
        out.writeBytes("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n");
        out.write(value.getBytes(StandardCharsets.UTF_8));
        out.writeBytes("\r\n");
    }

    private String readAllText(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) >= 0) bos.write(buf, 0, n);
        return bos.toString("UTF-8");
    }

    private long countBytes(Uri uri) throws Exception {
        long total = 0;
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            byte[] b = new byte[64 * 1024];
            int n;
            while ((n = is.read(b)) >= 0) total += n;
        }
        return total;
    }

    private String pickPrivacy(JSONArray options) {
        if (options == null || options.length() == 0) return "SELF_ONLY";
        for (int i = 0; i < options.length(); i++) if ("SELF_ONLY".equals(options.optString(i))) return "SELF_ONLY";
        for (int i = 0; i < options.length(); i++) if ("PUBLIC_TO_EVERYONE".equals(options.optString(i))) return "PUBLIC_TO_EVERYONE";
        return options.optString(0, "SELF_ONLY");
    }

    private void copyCaption() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Geo Redes", getCaption()));
        toast("Descripción copiada.");
    }

    private String getCaption() {
        return edtCaption == null ? "" : edtCaption.getText().toString();
    }

    private void setBusy(boolean busy) {
        if (progress != null) progress.setVisibility(busy ? View.VISIBLE : View.GONE);
    }

    private void log(String msg) {
        runOnUiThread(() -> {
            if (tvConsole != null) tvConsole.setText(msg + "\n\n" + tvConsole.getText());
            if (tvSettingsStatus != null) tvSettingsStatus.setText(apiSummaryDetailed() + "\n\nUltimo estado:\n" + msg);
            if (tvDiagnostic != null) tvDiagnostic.setText(msg + "\n\n" + tvDiagnostic.getText());
        });
    }

    private String apiSummary() {
        boolean tt = !prefs.getString("tiktok_token", "").isEmpty();
        boolean meta = !prefs.getString("meta_token", "").isEmpty();
        return "TikTok: " + (tt ? "conectado" : "sin conectar")
                + "   Meta: " + (meta ? "conectado" : "sin conectar")
                + "\nFB Page: " + safe(prefs.getString("fb_page_name", "-"))
                + "   IG: " + (prefs.getString("ig_user_id", "").isEmpty() ? "no detectado" : "detectado");
    }

    private String apiSummaryDetailed() {
        return "Estado de APIs\n"
                + "TikTok token: " + (!prefs.getString("tiktok_token", "").isEmpty() ? "OK" : "NO") + "\n"
                + "Meta token: " + (!prefs.getString("meta_token", "").isEmpty() ? "OK" : "NO") + "\n"
                + "Facebook página: " + safe(prefs.getString("fb_page_name", "NO")) + "\n"
                + "Instagram IG ID: " + safe(prefs.getString("ig_user_id", "NO")) + "\n\n"
                + "Nota: TikTok usa video.upload para enviar el video como borrador. Facebook publica en páginas. Instagram API requiere URL pública HTTPS del video.";
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(CARD);
        gd.setCornerRadius(dp(16));
        gd.setStroke(dp(1), Color.rgb(35, 48, 70));
        l.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, dp(6));
        l.setLayoutParams(lp);
        return l;
    }

    private TextView label(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setIncludeFontPadding(true);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private TextView pill(String t, int color) {
        TextView v = label(t, 13, color, true);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(12), 0, dp(12), 0);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(CARD2);
        gd.setCornerRadius(dp(18));
        gd.setStroke(dp(1), Color.rgb(50, 68, 95));
        v.setBackground(gd);
        return v;
    }

    private Button primaryButton(String t) { return button(t, Color.rgb(0, 122, 255), Color.WHITE); }
    private Button darkButton(String t) { return button(t, CARD2, TXT); }
    private Button smallButton(String t) { return button(t, Color.rgb(24, 34, 54), TXT); }

    private Button button(String t, int bg, int fg) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(13);
        b.setTextColor(fg);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bg);
        gd.setCornerRadius(dp(14));
        b.setBackground(gd);
        return b;
    }

    private CheckBox check(String t) {
        CheckBox cb = new CheckBox(this);
        cb.setText(t);
        cb.setTextColor(TXT);
        cb.setTextSize(12);
        cb.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
        return cb;
    }

    private EditText input(String hint, String value, boolean password) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setTextColor(TXT);
        e.setHintTextColor(Color.rgb(120, 130, 150));
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.rgb(10, 16, 28));
        gd.setCornerRadius(dp(12));
        gd.setStroke(dp(1), Color.rgb(45, 60, 85));
        e.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.topMargin = dp(8);
        e.setLayoutParams(lp);
        return e;
    }

    private String queryName(Uri uri) {
        String result = "video.mp4";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = c.getString(idx);
            }
        } catch (Exception ignored) { }
        return result == null ? "video.mp4" : result;
    }

    private long querySize(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.SIZE);
                if (idx >= 0) return c.getLong(idx);
            }
        } catch (Exception ignored) { }
        return 0;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private int parseInt(String s) { try { return s == null ? 0 : Integer.parseInt(s); } catch (Exception e) { return 0; } }
    private long parseLong(String s) { try { return s == null ? 0 : Long.parseLong(s); } catch (Exception e) { return 0; } }
    private double parseDouble(String s) { try { return s == null ? 0 : Double.parseDouble(s); } catch (Exception e) { return 0; } }
    private String safe(String s) { return s == null ? "" : s; }
    private String fmt(double d) { return d <= 0 ? "-" : String.format(Locale.US, "%.0f", d); }
    private String formatMb(long b) { return b <= 0 ? "-" : String.format(Locale.US, "%.1f MB", b / 1024.0 / 1024.0); }
    private String formatMbps(long bps) { return bps <= 0 ? "-" : String.format(Locale.US, "%.2f Mbps", bps / 1000.0 / 1000.0); }
    private String formatDuration(long ms) { long s = ms / 1000; return String.format(Locale.US, "%d:%02d", s / 60, s % 60); }
    private String shorten(String s, int n) { if (s == null) return ""; return s.length() <= n ? s : s.substring(0, Math.max(0, n - 3)) + "..."; }
    private String enc(String s) { try { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); } catch (Exception e) { return ""; } }
    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    static class VideoInfo {
        String name = "";
        String mime = "";
        String videoCodec = "";
        String status = "";
        String error = "";
        long sizeBytes;
        int width;
        int height;
        int rotation;
        int visualWidth;
        int visualHeight;
        long bitrate;
        long durationMs;
        double fps;
    }
}
