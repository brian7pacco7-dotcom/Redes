# Geo Redes v2

APK para analizar videos, mantener resolución original y publicar por API o de forma manual.

## Funciones

- Interfaz negra compacta.
- Análisis de video: resolución, orientación, FPS, bitrate, duración y peso.
- No recomprime ni baja resolución.
- Publicación API preparada para:
  - TikTok Content Posting API con FILE_UPLOAD.
  - Facebook Page Video API.
  - Instagram Reels API mediante URL pública HTTPS.
- Compartir manual como respaldo.

## Aviso importante

Para TikTok API necesitas una app registrada en TikTok Developers con Content Posting API y scope `video.publish` aprobado. Si la app no está auditada, TikTok puede restringir publicaciones a privado.

Para Meta necesitas App ID, App Secret, permisos de páginas y cuenta profesional vinculada. Instagram Graph API no acepta subir un archivo local directo para Reels: necesita `video_url` público HTTPS o un backend que aloje temporalmente el video.

## Compilar

Sube este proyecto a GitHub y ejecuta Actions.
