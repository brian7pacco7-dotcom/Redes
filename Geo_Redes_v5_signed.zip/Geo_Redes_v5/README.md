# Geo Redes v3

APK Android para analizar calidad real del video y publicar sin recomprimir.

## Nuevo en v3

- Interfaz negra compacta.
- Modo Diagnóstico API.
- Prueba de login TikTok.
- Prueba de token/usuario TikTok.
- Prueba de permisos TikTok con creator_info.
- Subida de prueba por TikTok API.
- Diagnóstico Meta: login, páginas, prueba Facebook.
- Botón para copiar reporte técnico.

## Importante

La app puede preparar y probar las APIs, pero TikTok/Meta solo permiten publicar si la app creada en sus paneles tiene permisos aprobados.

## Compilar

Sube este ZIP al repositorio y ejecuta el workflow de GitHub Actions que descomprime el ZIP y compila el APK.


## v4
- Icono actualizado con logo Geo Redes azul/cian.
- Se incluye Geo_Redes_logo_1024.png para subirlo a TikTok Developers.


## v5
- APK release firmada con keystore de prueba fijo.
- Package fijo para TikTok Sandbox/Android: com.bph.georedes
- Workflow compila app-release.apk firmado.
