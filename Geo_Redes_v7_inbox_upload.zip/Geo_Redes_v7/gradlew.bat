@echo off
echo Usa GitHub Actions o Linux/macOS con ./gradlew assembleDebug
exit /b 1
