package com.bph.publisherhd;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_PICK_VIDEO = 1001;

    private Uri selectedVideoUri;
    private VideoInfo lastVideoInfo;

    private TextView titleText;
    private TextView fileText;
    private TextView statusText;
    private TextView reportText;
    private EditText captionEdit;

    private boolean sequenceActive = false;
    private boolean waitingExternal = false;
    private long launchedAt = 0L;
    private int sequenceIndex = 0;

    private final ShareTarget[] targets = new ShareTarget[] {
            new ShareTarget("TikTok", "com.zhiliaoapp.musically", "com.zhiliaoapp.musically.go"),
            new ShareTarget("Instagram", "com.instagram.android", null),
            new ShareTarget("Facebook", "com.facebook.katana", null)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        scrollView.addView(root);

        titleText = new TextView(this);
        titleText.setText("Geo Redes");
        titleText.setTextSize(25);
        titleText.setTextColor(Color.rgb(13, 71, 161));
        titleText.setGravity(Gravity.CENTER_HORIZONTAL);
        titleText.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(titleText, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Analiza el video, protege su resolución original y lo comparte a TikTok, Instagram y Facebook desde las apps oficiales.");
        subtitle.setTextSize(14);
        subtitle.setTextColor(Color.rgb(60, 60, 60));
        subtitle.setPadding(0, dp(8), 0, dp(14));
        root.addView(subtitle, matchWrap());

        Button pickButton = button("Elegir video desde galería / Drive");
        pickButton.setOnClickListener(v -> pickVideo());
        root.addView(pickButton, matchWrapMarginTop(6));

        fileText = cardText("Archivo: todavía no seleccionaste video.");
        root.addView(fileText, matchWrapMarginTop(12));

        statusText = cardText("Estado HD: pendiente de análisis.");
        statusText.setTextColor(Color.rgb(97, 97, 97));
        root.addView(statusText, matchWrapMarginTop(10));

        reportText = cardText("Datos técnicos aparecerán aquí:\n- resolución\n- orientación\n- códec\n- FPS\n- bitrate\n- peso\n- duración");
        reportText.setTextSize(14);
        root.addView(reportText, matchWrapMarginTop(10));

        TextView capLabel = new TextView(this);
        capLabel.setText("Descripción / hashtags");
        capLabel.setTextSize(16);
        capLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        capLabel.setPadding(0, dp(16), 0, dp(6));
        root.addView(capLabel, matchWrap());

        captionEdit = new EditText(this);
        captionEdit.setHint("Escribe aquí la descripción. La app la copia antes de abrir cada red.");
        captionEdit.setTextSize(15);
        captionEdit.setMinLines(3);
        captionEdit.setGravity(Gravity.TOP | Gravity.START);
        captionEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        captionEdit.setBackgroundColor(Color.WHITE);
        captionEdit.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(captionEdit, matchWrap());

        Button copyButton = button("Copiar descripción");
        copyButton.setOnClickListener(v -> copyCaption());
        root.addView(copyButton, matchWrapMarginTop(8));

        Button publishAllButton = button("Publicar a TikTok + Instagram + Facebook");
        publishAllButton.setOnClickListener(v -> startAssistedSequence());
        root.addView(publishAllButton, matchWrapMarginTop(16));

        Button tiktokButton = button("Abrir solo TikTok");
        tiktokButton.setOnClickListener(v -> shareWithWarning(targets[0]));
        root.addView(tiktokButton, matchWrapMarginTop(8));

        Button instagramButton = button("Abrir solo Instagram");
        instagramButton.setOnClickListener(v -> shareWithWarning(targets[1]));
        root.addView(instagramButton, matchWrapMarginTop(8));

        Button facebookButton = button("Abrir solo Facebook");
        facebookButton.setOnClickListener(v -> shareWithWarning(targets[2]));
        root.addView(facebookButton, matchWrapMarginTop(8));

        TextView note = new TextView(this);
        note.setText("Nota importante: esta versión no baja resolución ni recomprime. Comparte el archivo original. Cada red social puede volver a procesar el video al publicarlo.");
        note.setTextSize(13);
        note.setTextColor(Color.rgb(80, 80, 80));
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note, matchWrap());

        setContentView(scrollView);
    }

    private Button button(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(Color.rgb(21, 101, 192));
        button.setPadding(dp(8), dp(8), dp(8), dp(8));
        return button;
    }

    private TextView cardText(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(Color.rgb(35, 35, 35));
        tv.setBackgroundColor(Color.WHITE);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        return tv;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrapMarginTop(int topDp) {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(topDp);
        return params;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedVideoUri = data.getData();
            try {
                int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(selectedVideoUri, flags);
            } catch (Exception ignored) {
                // Algunos proveedores no permiten permiso persistente. No bloqueamos la app por eso.
            }
            analyzeSelectedVideo();
        }
    }

    private void analyzeSelectedVideo() {
        if (selectedVideoUri == null) return;
        try {
            lastVideoInfo = readVideoInfo(selectedVideoUri);
            fileText.setText("Archivo seleccionado:\n" + lastVideoInfo.displayName + "\nTamaño: " + formatBytes(lastVideoInfo.sizeBytes));
            statusText.setText(lastVideoInfo.statusTitle + "\n" + lastVideoInfo.statusMessage);
            statusText.setTextColor(lastVideoInfo.statusColor);
            reportText.setText(lastVideoInfo.buildReport());
        } catch (Exception e) {
            lastVideoInfo = null;
            statusText.setTextColor(Color.rgb(198, 40, 40));
            statusText.setText("No se pudo analizar el video.\n" + e.getMessage());
            reportText.setText("Prueba con un MP4 normal exportado desde CapCut o desde la cámara.");
        }
    }

    private VideoInfo readVideoInfo(Uri uri) throws Exception {
        VideoInfo info = new VideoInfo();
        info.uri = uri;
        info.fileMime = safeString(getContentResolver().getType(uri));
        info.displayName = getDisplayName(uri);
        info.sizeBytes = getSize(uri);

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            info.durationMs = parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            info.rotation = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
            int metaWidth = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int metaHeight = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            long metaBitrate = parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE));
            if (metaWidth > 0) info.width = metaWidth;
            if (metaHeight > 0) info.height = metaHeight;
            if (metaBitrate > 0) info.bitrate = metaBitrate;
        } finally {
            try { retriever.release(); } catch (Exception ignored) { }
        }

        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(this, uri, null);
            int count = extractor.getTrackCount();
            for (int i = 0; i < count; i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.containsKey(MediaFormat.KEY_MIME) ? format.getString(MediaFormat.KEY_MIME) : "";
                if (mime != null && mime.startsWith("video/")) {
                    info.videoMime = mime;
                    if (format.containsKey(MediaFormat.KEY_WIDTH)) info.width = format.getInteger(MediaFormat.KEY_WIDTH);
                    if (format.containsKey(MediaFormat.KEY_HEIGHT)) info.height = format.getInteger(MediaFormat.KEY_HEIGHT);
                    if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) info.frameRate = format.getInteger(MediaFormat.KEY_FRAME_RATE);
                    if (format.containsKey(MediaFormat.KEY_BIT_RATE)) info.bitrate = Math.max(info.bitrate, format.getInteger(MediaFormat.KEY_BIT_RATE));
                } else if (mime != null && mime.startsWith("audio/")) {
                    info.audioMime = mime;
                }
            }
        } finally {
            try { extractor.release(); } catch (Exception ignored) { }
        }

        if (info.width <= 0 || info.height <= 0) {
            throw new FileNotFoundException("No se pudo leer la resolución del video.");
        }

        info.calculateStatus();
        return info;
    }

    private String getDisplayName(Uri uri) {
        String result = "video seleccionado";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result;
    }

    private long getSize(Uri uri) {
        long result = -1;
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (index >= 0) result = cursor.getLong(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result;
    }

    private void copyCaption() {
        String caption = captionEdit.getText().toString();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Geo Redes caption", caption));
        Toast.makeText(this, "Descripción copiada", Toast.LENGTH_SHORT).show();
    }

    private void startAssistedSequence() {
        if (!canShare()) return;
        String warning = getShareWarningText();
        new AlertDialog.Builder(this)
                .setTitle("Publicación asistida")
                .setMessage(warning + "\n\nSe abrirá una red a la vez. Publica ahí, vuelve a esta APK y continúa con la siguiente.")
                .setPositiveButton("Empezar", (dialog, which) -> {
                    sequenceActive = true;
                    sequenceIndex = 0;
                    launchSequenceTarget();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void launchSequenceTarget() {
        if (sequenceIndex >= targets.length) {
            sequenceActive = false;
            waitingExternal = false;
            Toast.makeText(this, "Secuencia terminada", Toast.LENGTH_LONG).show();
            return;
        }
        waitingExternal = true;
        launchedAt = System.currentTimeMillis();
        shareToTarget(targets[sequenceIndex]);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sequenceActive && waitingExternal && launchedAt > 0 && System.currentTimeMillis() - launchedAt > 1200) {
            waitingExternal = false;
            sequenceIndex++;
            if (sequenceIndex < targets.length) {
                new AlertDialog.Builder(this)
                        .setTitle("Continuar")
                        .setMessage("Ahora toca abrir " + targets[sequenceIndex].name + ".")
                        .setPositiveButton("Abrir " + targets[sequenceIndex].name, (dialog, which) -> launchSequenceTarget())
                        .setNegativeButton("Terminar", (dialog, which) -> {
                            sequenceActive = false;
                            waitingExternal = false;
                        })
                        .show();
            } else {
                sequenceActive = false;
                Toast.makeText(this, "Listo. Revisa tus redes.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void shareWithWarning(ShareTarget target) {
        if (!canShare()) return;
        String warning = getShareWarningText();
        new AlertDialog.Builder(this)
                .setTitle("Abrir " + target.name)
                .setMessage(warning + "\n\nLa descripción se copiará al portapapeles para que la pegues si la red social no la recibe automáticamente.")
                .setPositiveButton("Abrir", (dialog, which) -> shareToTarget(target))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private boolean canShare() {
        if (selectedVideoUri == null) {
            Toast.makeText(this, "Primero elige un video", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (lastVideoInfo == null) {
            Toast.makeText(this, "Primero analiza el video", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private String getShareWarningText() {
        if (lastVideoInfo == null) return "No hay análisis técnico.";
        return "Resolución visual detectada: " + lastVideoInfo.displayWidth + " x " + lastVideoInfo.displayHeight +
                "\nSalida de la APK: archivo original, sin bajar resolución.\nEstado: " + lastVideoInfo.statusTitle;
    }

    private void shareToTarget(ShareTarget target) {
        if (selectedVideoUri == null) return;
        copyCaption();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_STREAM, selectedVideoUri);
        intent.putExtra(Intent.EXTRA_TEXT, captionEdit.getText().toString());
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newRawUri("video", selectedVideoUri));

        boolean launched = tryPackage(intent, target.primaryPackage);
        if (!launched && target.secondaryPackage != null) launched = tryPackage(intent, target.secondaryPackage);
        if (!launched) {
            try {
                Intent chooser = Intent.createChooser(intent, "Compartir en " + target.name);
                startActivity(chooser);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "No se encontró una app para compartir", Toast.LENGTH_LONG).show();
            }
        }
    }

    private boolean tryPackage(Intent baseIntent, String packageName) {
        try {
            Intent direct = new Intent(baseIntent);
            direct.setPackage(packageName);
            if (direct.resolveActivity(getPackageManager()) == null) return false;
            startActivity(direct);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String safeString(String value) {
        return value == null ? "no detectado" : value;
    }

    private int parseInt(String value) {
        try { return value == null ? 0 : Integer.parseInt(value); } catch (Exception e) { return 0; }
    }

    private long parseLong(String value) {
        try { return value == null ? 0 : Long.parseLong(value); } catch (Exception e) { return 0; }
    }

    private String formatBytes(long bytes) {
        if (bytes < 0) return "no detectado";
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb);
        double gb = mb / 1024.0;
        return String.format(Locale.US, "%.2f GB", gb);
    }

    private String formatDuration(long ms) {
        if (ms <= 0) return "no detectado";
        long seconds = ms / 1000;
        long min = seconds / 60;
        long sec = seconds % 60;
        return String.format(Locale.US, "%d:%02d", min, sec);
    }

    private String formatMbps(long bitrate) {
        if (bitrate <= 0) return "no detectado";
        return String.format(Locale.US, "%.2f Mbps", bitrate / 1_000_000.0);
    }

    private static class ShareTarget {
        final String name;
        final String primaryPackage;
        final String secondaryPackage;
        ShareTarget(String name, String primaryPackage, String secondaryPackage) {
            this.name = name;
            this.primaryPackage = primaryPackage;
            this.secondaryPackage = secondaryPackage;
        }
    }

    private class VideoInfo {
        Uri uri;
        String displayName = "video";
        String fileMime = "no detectado";
        String videoMime = "no detectado";
        String audioMime = "no detectado";
        long sizeBytes = -1;
        int width = 0;
        int height = 0;
        int rotation = 0;
        int displayWidth = 0;
        int displayHeight = 0;
        int frameRate = 0;
        long bitrate = 0;
        long durationMs = 0;
        String statusTitle = "Estado pendiente";
        String statusMessage = "";
        int statusColor = Color.rgb(97, 97, 97);

        void calculateStatus() {
            boolean rotated = rotation == 90 || rotation == 270;
            displayWidth = rotated ? height : width;
            displayHeight = rotated ? width : height;
            boolean vertical = displayHeight >= displayWidth;
            boolean fullHd = vertical && displayWidth >= 1080 && displayHeight >= 1920;
            boolean hd = vertical && displayWidth >= 720 && displayHeight >= 1280;
            boolean low = displayWidth <= 540 || displayHeight <= 960;
            boolean codecGood = "video/avc".equalsIgnoreCase(videoMime) || "video/hevc".equalsIgnoreCase(videoMime) || "video/mp4v-es".equalsIgnoreCase(videoMime);
            boolean fpsGood = frameRate <= 0 || (frameRate >= 24 && frameRate <= 60);
            boolean bitrateGood = bitrate <= 0 || bitrate >= 4_000_000;
            boolean frameIsLandscapeButRotated = vertical && width > height && rotated;

            List<String> notes = new ArrayList<>();
            if (!vertical) notes.add("No está vertical 9:16. Para TikTok/Reels puede verse recortado o con baja calidad.");
            if (frameIsLandscapeButRotated) notes.add("El archivo usa rotación por metadatos. Si una red lo procesa mal, re-exporta vertical real 1080x1920.");
            if (!codecGood) notes.add("Códec no ideal. Recomendado: H.264 en MP4.");
            if (!fpsGood) notes.add("FPS fuera del rango recomendado. Recomendado: 30 fps.");
            if (!bitrateGood) notes.add("Bitrate bajo. Puede perder nitidez al publicarse.");
            if (low) notes.add("Resolución baja detectada. Aunque se escale, no será HD real.");

            if (fullHd && codecGood && fpsGood && bitrateGood && !frameIsLandscapeButRotated) {
                statusTitle = "APTO FULL HD";
                statusMessage = "Se compartirá el archivo original en " + displayWidth + " x " + displayHeight + ".";
                statusColor = Color.rgb(27, 94, 32);
            } else if (fullHd) {
                statusTitle = "APTO HD CON ALERTA";
                statusMessage = "Resolución buena, pero revisa: " + joinNotes(notes);
                statusColor = Color.rgb(245, 124, 0);
            } else if (hd) {
                statusTitle = "APTO HD BASICO";
                statusMessage = "No es Full HD 1080x1920, pero es HD vertical. Se compartirá sin bajar resolución.";
                statusColor = Color.rgb(46, 125, 50);
            } else {
                statusTitle = "RIESGO DE BAJA CALIDAD";
                statusMessage = notes.isEmpty() ? "El video no cumple el tamaño HD recomendado." : joinNotes(notes);
                statusColor = Color.rgb(198, 40, 40);
            }
        }

        String joinNotes(List<String> notes) {
            if (notes.isEmpty()) return "sin alertas importantes.";
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < notes.size(); i++) {
                if (i > 0) builder.append(" ");
                builder.append(notes.get(i));
            }
            return builder.toString();
        }

        String buildReport() {
            StringBuilder sb = new StringBuilder();
            sb.append("DATOS DEL ARCHIVO\n");
            sb.append("Nombre: ").append(displayName).append("\n");
            sb.append("Peso: ").append(formatBytes(sizeBytes)).append("\n");
            sb.append("MIME archivo: ").append(fileMime).append("\n\n");

            sb.append("VIDEO\n");
            sb.append("Resolución del archivo: ").append(width).append(" x ").append(height).append("\n");
            sb.append("Rotación: ").append(rotation).append("°\n");
            sb.append("Resolución visual: ").append(displayWidth).append(" x ").append(displayHeight).append("\n");
            sb.append("Orientación visual: ").append(displayHeight >= displayWidth ? "Vertical" : "Horizontal").append("\n");
            sb.append("Códec video: ").append(videoMime).append("\n");
            sb.append("FPS: ").append(frameRate > 0 ? frameRate : "no detectado").append("\n");
            sb.append("Bitrate: ").append(formatMbps(bitrate)).append("\n");
            sb.append("Duración: ").append(formatDuration(durationMs)).append("\n\n");

            sb.append("AUDIO\n");
            sb.append("Códec audio: ").append(audioMime).append("\n\n");

            sb.append("SALIDA DE LA APK\n");
            sb.append("Se enviará el archivo original.\n");
            sb.append("No se recomprime.\n");
            sb.append("No se baja la resolución.\n");
            sb.append("Resolución que se enviará: ").append(displayWidth).append(" x ").append(displayHeight).append("\n\n");

            sb.append("ESTADO\n");
            sb.append(statusTitle).append("\n").append(statusMessage);
            return sb.toString();
        }
    }
}
