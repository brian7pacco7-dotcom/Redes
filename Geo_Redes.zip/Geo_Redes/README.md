# Geo Redes

APK Android para analizar la calidad real de un video y compartirlo en TikTok, Instagram y Facebook usando las apps oficiales.

## Qué hace

- Elige video desde galería, archivos o Google Drive.
- Lee datos técnicos:
  - resolución real del archivo
  - resolución visual
  - rotación
  - formato/MIME
  - códec de video
  - códec de audio
  - FPS
  - bitrate
  - peso
  - duración
- Indica si el archivo está:
  - APTO FULL HD
  - APTO HD CON ALERTA
  - APTO HD BÁSICO
  - RIESGO DE BAJA CALIDAD
- Comparte el archivo original sin recomprimir y sin bajar resolución.
- Copia la descripción al portapapeles antes de abrir cada red social.
- Tiene botones para TikTok, Instagram y Facebook.

## Importante

Esta primera versión es publicación asistida, no autopublicación total.

La app abre TikTok, Instagram o Facebook con el video. Tú revisas y presionas Publicar dentro de cada red social.

Esto evita plataformas intermedias que puedan bajar la calidad o pedir pago. La publicación automática total requiere APIs oficiales, permisos, tokens y aprobación de TikTok/Meta.

## Regla de calidad

La app no comprime más. Comprimir más no mejora HD. La app protege el archivo original:

- Si el video ya es 1080 x 1920, lo comparte así.
- Si es 720 x 1280, lo comparte así.
- Si es 540 x 960, avisa riesgo de baja calidad.
- Si está girado o tiene rotación rara, avisa.

## Cómo compilar en GitHub usando ZIP

Sube este ZIP al repositorio y usa el workflow `build-apk-from-zip.yml` corregido.

Artifact esperado:

**Geo-Redes-debug-apk**

## Cómo abrir en Android Studio

1. Android Studio > Open.
2. Selecciona la carpeta `Geo_Redes`.
3. Espera sincronización Gradle.
4. Build > Build APK(s).

## Paquete

`com.bph.publisherhd`

## Versión

1.0 debug
