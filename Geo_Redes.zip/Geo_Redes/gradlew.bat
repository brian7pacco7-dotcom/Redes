@echo off
echo Este proyecto usa gradlew para Linux/GitHub Actions. En Windows abre con Android Studio o instala Gradle.
exit /b 1
